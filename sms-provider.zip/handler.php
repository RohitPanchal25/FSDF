<?php
require_once(__DIR__ . '/crest.php');

CRest::setLog($_REQUEST, 'handler');
print_r($_REQUEST);