<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="css/app.css">
	<!--link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"-->
	<title>FASTSMS</title>
</head>
<body>

<?php
require_once(__DIR__ . '/crest.php');

// echo "<pre>"; print_r($_REQUEST); echo "</pre>";
?>

<div class="container-fluid">
	<div class="row">
		<div class="col-sm-12 col-xs-12 col-md-12 col-lg-12">
			<form id="sms-settings">
				<input type="hidden" name="save" value="Y">
				<input type="hidden" name="access_token" value="<?=$_REQUEST['AUTH_ID'];?>">
				<input type="hidden" name="refresh_token" value="<?=$_REQUEST['REFRESH_ID'];?>">
				<input type="hidden" name="domain" value="<?=$_REQUEST['DOMAIN'];?>">
				<input type="hidden" name="member_id" value="<?=$_REQUEST['member_id'];?>">
				<div class="form-group">
					<label for="sms_token">API-key FastSMS</label>
					<input type="text" class="form-control" name="sms_token" id="sms_token" value="saved API-key" placeholder="FastSMS API token">
				</div>
				<button type="submit" class="btn btn-primary btn-lg btn-save">Update</button>
			</form>
		</div>
	</div>

</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="//api.bitrix24.com/api/v1/dev/"></script>

<script>
	BX24.init(function() {
		var size = BX24.getScrollSize();
		// BX24.resizeWindow(size.scrollWidth, 600);
		BX24.fitWindow();

		console.log(size);

		$('#sms-settings').submit(function(e) {
			e.preventDefault();
			/**
			 * Save sms api key in external DB
			 */
		});

	});
</script>

</body>
</html>